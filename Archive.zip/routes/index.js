var express = require("express");
var router = express.Router();
const OpenAI = require("openai") ;
const https = require('https');
const axios = require('axios');
const Users = require("../models/Users");
const jwt = require('jsonwebtoken');
const JWT_SECRET = 'your_secret_key'; // This should be stored securely and not hardcoded in production
const TOKEN_EXPIRATION = '1h'; // Token expires in 1 hour
const bcrypt = require('bcrypt');

/* GET home page. */
router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});

router.get("/dashboard", function (req, res, next) {
  res.render("dashboard", { title: "Express" });
});

router.get("/settings", function (req, res, next) {
  res.render("settings", { title: "Express" });
});

router.get("/login", function (req, res, next) {
  res.render("login", { title: "Express" ,error : req.flash('error' || undefined)});
});

router.get("/signup", function (req, res, next) {
  res.render("signup", { title: "Express" });
});

router.get("/create-password/:token", function (req, res, next) {
  res.render("create-password", { token: req.params.token  });
});

router.post("/create-password", async function (req, res, next) {
  const { token, password, confirmPassword } = req.body;

    // Step 1: Verify the token
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        const userId = decoded.userId;

        console.log(decoded,userId)

        // Step 2: Validate the passwords
        if (password !== confirmPassword) {
            return res.status(400).json({ message: 'Passwords do not match' });
        }

        // Step 3: Hash the password
        const saltRounds = 10; // You can adjust the salt rounds based on your security requirement
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Step 4: Update the User model
        const user = await Users.findById( userId );
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        user.password = hashedPassword;
        await user.save();

        return res.json({ status: true, message: 'Password has been reset successfully' });
    } catch (error) {
        // Handle errors, such as token expiration or invalid token
        return res.status(401).json({ message: 'Invalid or expired token' });
    }
});



// Users who hit this endpoint will be redirected to the authorization prompt
router.get('/authorize', (req, res) => {
  const oauthUri = 'https://accounts.freelancer-sandbox.com/oauth/authorize';
  const clientId = '29924658-592c-47bf-bee8-8cc7d7004c92';
  const redirectUri = 'http://localhost:3000/freelancer/callback';
  const prompt = 'select_account consent';
  const advancedScopes = '2 6';
  const authorizationUrl = `${oauthUri}?response_type=code&client_id=${clientId}&redirect_uri=${redirectUri}&scope=basic&prompt=${prompt}&advanced_scopes=${advancedScopes}`;
  res.redirect(authorizationUrl);
});


router.get('/freelancer/callback', async (req,res)=>{
  let code = req.query.code
  const clientId = '29924658-592c-47bf-bee8-8cc7d7004c92';
  const url = "https://accounts.freelancer-sandbox.com/oauth/token";

  const payload = `grant_type=authorization_code&code=${code}&client_id=${clientId}&client_secret=318fffa5a870c0d6c9eb8242b9adc0942b70fd73af32c88bd58c9f70b58c14532c496926b0a2e95ec497c20e5cbfdd009ed8c97a3b4f9cbb568333973ee1a51c&redirect_uri=http://localhost:3000/freelancer/callback`;
  const headers = {'Content-Type': 'application/x-www-form-urlencoded'};

  try {
    
    let response = await axios.post(url, payload, {headers})
  
    let data = await getSelfData(response.data.access_token)
          
    if(data.status){
      console.log("1")
      // req.session.user = data.user
      res.redirect(`/create-password/${data.token}`)
    }else{
      console.log("2")
      req.flash('error', "Error Occured. Try again later.")
      res.redirect('/login')
    }
  } catch (error) {
    req.flash('error', "Error Occured. Try again later.")
    res.redirect('/login')
  }
     

})

const getSelfData = async (accessToken)=>{
  const url = "https://freelancer-sandbox.com/api/users/0.1/self";
  
  const headers = {'freelancer-oauth-v1': accessToken};
  
  try {
    
    let response = await axios.get(url, { headers })
      
    if(response.data.status = 'success'){
      console.log("s1")
      let userr = new Users({...response.data.result, role : 'freelancer'})
      await userr.save()
      console.log("s2")
  
      let user = await Users.findOne({id : response.data.result.id});
      console.log("s3")

      const token = jwt.sign({
        userId: user._id
      }, JWT_SECRET, {expiresIn: TOKEN_EXPIRATION});
      return {status : true, user, token}
    }else{
      console.log("s4")
      return {status : false, user : undefined}
    }
  } catch (error) {
    return {status : false, user : undefined}
  }
  
}

router.get('/myBids', (req,res)=>{
  res.render('myBids')
})

router.get('/search', (req,res)=>{
  res.render('search')
})

router.get('/bidai', (req,res)=>{
  res.render('bidmanAi')
})

router.get('/autobid', (req,res)=>{
  res.render('autobid')
})

router.get('/skills', (req,res)=>{
  res.render('skills')
})

router.get('/skills-sets', (req,res)=>{
  res.render('skills-sets')
})

router.get('/countries', (req,res)=>{
  res.render('countries')
})

router.get('/client-stats', (req,res)=>{
  res.render('clientStats')
})

router.get('/budget', (req,res)=>{
  res.render('budget')
})
router.get('/bidPrice', (req,res)=>{
  res.render('bidPrice')
})

router.get('/period', (req,res)=>{
  res.render('period')
})

router.get('/tcats', (req,res)=>{
  res.render('tcats')
})

router.get('/temp', (req,res)=>{
  res.render('temp')
})

router.get('/passChange', (req,res)=>{
  res.render('passChange')
})

router.get('/guide', (req,res)=>{
  res.render('guide')
})





router.get('/logout',async (req,res)=>{
  delete req.session.user
  res.redirect('/login')
})


router.get('/chatgpt',async (req,res)=>{
  try {
    const openai = new OpenAI({apiKey:"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"});

    async function getLocation() {
      const response = await fetch("https://ipapi.co/json/");
      const locationData = await response.json();
      return locationData;
    }

    async function getCurrentWeather(latitude, longitude) {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=apparent_temperature`;
      const response = await fetch(url);
      const weatherData = await response.json();
      return weatherData;
    }

    const tools = [
      {
        type: "function",
        function: {
          name: "getCurrentWeather",
          description: "Get the current weather in a given location",
          parameters: {
            type: "object",
            properties: {
              latitude: {
                type: "string",
              },
              longitude: {
                type: "string",
              },
            },
            required: ["longitude", "latitude"],
          },
        }
      },
      {
        type: "function",
        function: {
          name: "getLocation",
          description: "Get the user's location based on their IP address",
          parameters: {
            type: "object",
            properties: {},
          },
        }
      },
    ];

    const messages = [
      {
        role: "system",
        content:
          "You are a helpful assistant. Only use the functions you have been provided with.",
      },
    ];

    async function agent(userInput) {
      messages.push({
        role: "user",
        content: userInput,
      });
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo-0125",
        messages: messages,
        tools: tools,
      });
      // console.log(response);

      const availableTools = {
        getCurrentWeather,
        getLocation,
      };
      
      const { finish_reason, message } = response.choices[0];
   
      if (finish_reason === "tool_calls" && message.tool_calls) {
        const functionName = message.tool_calls[0].function.name;
        const functionToCall = availableTools[functionName];
        const functionArgs = JSON.parse(message.tool_calls[0].function.arguments);
        const functionArgsArr = Object.values(functionArgs);
        const functionResponse = await functionToCall.apply(null, functionArgsArr);
        console.log(functionName, functionToCall, JSON.parse(message.tool_calls[0].function.arguments, functionResponse));
      }
    }

    const response = agent("Where am I located right now?");

    


  } catch (error) {
    console.log(error)
  }

})

module.exports = router;
