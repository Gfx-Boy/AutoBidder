const mongoose = require("mongoose")

const UsersSchema = mongoose.Schema({
    id : String,
    username : String,
    password : String,
    displayName : String,
    publicName : String,
    location : Object,
    freelancer_status : Object,
    primary_currency : Object,
    name : { type: String },
    primary_language : String,
    timezone : Object,
    age : Number,
    gender : String,
    username : { type: String },
    email : { type: String },
    phone : { type: String },
    role : { type: String },
    password : { type: String },
    token : { type: Object },
},{ timestamps: true })


module.exports = mongoose.model("Users", UsersSchema)